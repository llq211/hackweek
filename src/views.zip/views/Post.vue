<template>
    <div class="Body">
        <div class="box">
            <div class="img">
                <van-image
                    width="160px"
                    height="160px"
                    fit="cover"
                    src="https://img.yzcdn.cn/vant/cat.jpeg"
                    />
                <div class="photograph">
                    <van-icon name="photograph" color="#FF9E9A" size="33px"/>
                </div>
            </div>
            <div class="sort">
                <p style="font-size:15px; color: #FFFFFF;font-family: HYZhengYuan; text-indent:33px;">发 布 分 类</p>
                <div class="list">
                    <p style="font-size: 15px; color: #92A0FF; font-family: HYZhengYuan; text-indent:20px;">时装</p>
                    <Dropdown/>
                </div>
            </div>
            <div class="content_box">
                <div class="content">
                    <div class="title">
                        <p style="font-size: 15px;">标题</p>
                        <p>————————</p>
                    </div>
                    <div class="detail">
                        <p style="font-size: 10px;">请描述你的分享...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Dropdown from '../components/Dropdown.vue';
    import Vue from 'vue';
    import { Image as VanImage } from 'vant';
    import { Icon } from 'vant';

    Vue.use(Icon);
    Vue.use(VanImage);

    export default{
		name:'Post',
		components:{
            Dropdown,
		}
	};
</script>

<style scoped>
.Body{
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    overflow-y: auto;
    background-color: #F5E0E0;
}
.box{
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;  
    align-items: center;
}
.img{
    width: 100%;
    height: 200px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.photograph{
    width: 160px;
    height: 160px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 5px;
    box-shadow: 2px 2px 5px 2px #b9b8b8;
    margin: 20px 0px 20px 13px;
    background-color:#FFFFFF;

}
.sort{
    width: 335px;
    height: 40px;
    border-radius: 15px;
    background-color: #FF9E9A;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0.5px 2px 3px 0.7px #aca9a9;
}
.list{
    width: 210px;
    height: 40px;
    border-radius: 15px;
    background-color: #FFFFFF;
    box-shadow: 0.5px 2px 3px 0.7px #aca9a9;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.content_box{
    width: 335px;
    height: 50%;
    background-color: #FFFFFF;
    color: #FF9E9A;
    margin-top: 20px;
    box-shadow: 0.5px 2px 3px 0.7px #aca9a9;
    border-radius: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
}
.content{
    width: 88%;
    height: 92%;
    /* background-color: violet; */
    display: flex;
    flex-direction: column;
}
.title{
    width: 105px;
    height: 30px;
    color: #FF9E9A;
    display: flex;
    flex-direction: column;
}
.detail{
    /* background-color: rgb(227, 238, 130); */
    width: 100%;
    height: 90%;
    margin-top: 10px;
    color: #FF9E9A;
}
</style>